--truncate public.shipping_agreement;
insert into public.shipping_agreement
(agreement_id, agreement_number, agreement_rate, agreement_commission)
select 
	arr[1]::int4 as agreement_id,
	arr[2]::text as agreement_number,
	arr[3]::numeric(14, 3) as agreement_rate,
	arr[4]::numeric(14, 3) as agreement_commission
from (
		select 
			distinct regexp_split_to_array(vendor_agreement_description,':+') as arr,vendor_agreement_description
		from public.shipping
) step_1
;

--truncate public.shipping_country_rates;
insert into public.shipping_country_rates
(id, shipping_country, shipping_country_base_rate)
select 
	nextval('public.shipping_country_rates_id_sequence') as id,
	shipping_country,
	shipping_country_base_rate
from 
(
	select 
		distinct shipping_country,
		shipping_country_base_rate
	from public.shipping
) step_1;
DROP SEQUENCE public.shipping_country_rates_id_sequence;

--truncate public.shipping_transfer;
insert into public.shipping_transfer
(id, transfer_type, transfer_model, shipping_transfer_rate)
select 
	nextval('public.shipping_transfer_id_sequence') as id,
	arr[1]::text as transfer_type,
	arr[2]::text as transfer_model,
	shipping_transfer_rate::numeric(14, 3) as shipping_transfer_rate
from 
(
	select 
		distinct regexp_split_to_array(shipping_transfer_description,':+') as arr,
		shipping_transfer_rate
	from public.shipping
) step_1;
DROP SEQUENCE public.shipping_transfer_id_sequence;

--truncate public.shipping_info;
insert into public.shipping_info
(shipping_id, vendor_id, payment_amount, shipping_plan_datetime, shipping_transfer_id, shipping_agreement_id, shipping_country_rate_id)
select 
	distinct shipping_id,
	vendor_id,
	payment_amount,
	shipping_plan_datetime,
	st.id as shipping_transfer_id,
	sa.agreement_id as shipping_agreement_id,
	scr.id as shipping_country_rate_id
from 
(
		select 
			distinct shipping_id,
			vendor_id,
			payment_amount,
			shipping_plan_datetime,
			regexp_split_to_array(shipping_transfer_description,':+') as transfer,
			regexp_split_to_array(vendor_agreement_description,':+') as agreement_id,
			shipping_country
		from public.shipping
) s
left join public.shipping_transfer st on st.transfer_type=s.transfer[1]::text
										and st.transfer_model=s.transfer[2]::text
left join public.shipping_agreement sa on sa.agreement_id=s.agreement_id[1]::int4
left join public.shipping_country_rates scr on scr.shipping_country=s.shipping_country;

--truncate public.shipping_status;
insert into public.shipping_status
(shipping_id, status, state, shipping_start_fact_datetime, shipping_start_end_datetime)
select 
	shipping_id, 
	status, 
	state, 
	shipping_start_fact_datetime, 
	shipping_start_end_datetime
from 
(
select 
	s.shipping_id,
	s.status,
	s.state,
	sb.state_datetime as shipping_start_fact_datetime,
	sr.state_datetime as shipping_start_end_datetime,
	row_number() over(partition by s.shipping_id order by s.state_datetime desc) as rn
from public.shipping s
left join 
			(select 
					shipping_id, state_datetime
			from public.shipping
			where state='booked'
			) sb on sb.shipping_id = s.shipping_id
left join 
			(select 
					shipping_id, state_datetime
			from public.shipping
			where state='received'
			) sr on sr.shipping_id = s.shipping_id
) step_1
where rn=1;