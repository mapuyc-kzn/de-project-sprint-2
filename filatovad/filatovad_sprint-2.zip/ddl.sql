drop table if exists public.shipping_agreement;
create table public.shipping_agreement
(
	agreement_id int4,
	agreement_number text,
	agreement_rate numeric(14, 3),
	agreement_commission numeric(14, 3),
	CONSTRAINT shipping_agreement_pkey PRIMARY KEY (agreement_id)
);

CREATE SEQUENCE public.shipping_country_rates_id_sequence start 1;
drop table if exists public.shipping_country_rates;
create table public.shipping_country_rates
(
	id int2,
	shipping_country text,
	shipping_country_base_rate numeric(14, 3),
	CONSTRAINT shipping_country_rates_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE public.shipping_transfer_id_sequence start 1;
drop table if exists public.shipping_transfer;
create table public.shipping_transfer
(
	id int2,
	transfer_type text,
	transfer_model text,
	shipping_transfer_rate numeric(14, 3),
	CONSTRAINT shipping_transfer_pkey PRIMARY KEY (id)
);

drop table if exists public.shipping_info;
create table public.shipping_info
(
	shipping_id int8,
	vendor_id int8,
	payment_amount numeric(14, 3),
	shipping_plan_datetime timestamp,
	shipping_transfer_id int2,
	shipping_agreement_id int4,
	shipping_country_rate_id int2,
	CONSTRAINT shipping_info_pkey PRIMARY KEY (shipping_id),
	FOREIGN KEY (shipping_transfer_id) REFERENCES public.shipping_transfer(id),
	FOREIGN KEY (shipping_agreement_id) REFERENCES public.shipping_agreement(agreement_id),
	FOREIGN KEY (shipping_country_rate_id) REFERENCES public.shipping_country_rates(id)
);

drop table if exists public.shipping_status;
create table public.shipping_status
(
	shipping_id int8,
	status text,
	state text,
	shipping_start_fact_datetime timestamp,
	shipping_start_end_datetime timestamp,
	CONSTRAINT shipping_status_pkey PRIMARY KEY (shipping_id)
);

create view public.shipping_datamart
as
select 
	ss.shipping_id,
	si.vendor_id,
	st.transfer_type,
	(ss.shipping_start_end_datetime::date - ss.shipping_start_fact_datetime::date)::int2 as full_day_at_shipping, 
	case
		when ss.shipping_start_fact_datetime::date>shipping_plan_datetime::date
			then 1
		else 0
	end as is_delay,
	case
		when ss.status='finished'
			then 1
		else 0
	end as is_shipping_finish,
	coalesce((ss.shipping_start_end_datetime::date - si.shipping_plan_datetime::date)::int2,0) as delay_day_at_shipping,
	(si.payment_amount * (coalesce(scr.shipping_country_base_rate,0) + coalesce(sa.agreement_rate,0) + coalesce(st.shipping_transfer_rate,0)))::numeric(14, 3) as vat,
	(si.payment_amount * coalesce(sa.agreement_commission,0))::numeric(14, 3) as profit
from public.shipping_info si
left join public.shipping_status ss on si.shipping_id = ss.shipping_id
left join public.shipping_transfer st on st.id = si.shipping_transfer_id
left join public.shipping_country_rates scr on scr.id = si.shipping_country_rate_id
left join public.shipping_agreement sa on sa.agreement_id = si.shipping_agreement_id;