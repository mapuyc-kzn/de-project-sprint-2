drop table if exists public.shipping_agreement;
create table public.shipping_agreement
(
	agreement_id int4,
	agreement_number text,
	agreement_rate numeric(14, 3),
	agreement_commission numeric(14, 3),
	CONSTRAINT shipping_agreement_pkey PRIMARY KEY (agreement_id)
);

CREATE SEQUENCE public.shipping_country_rates_id_sequence start 1;
drop table if exists public.shipping_country_rates;
create table public.shipping_country_rates
(
	id int2,
	shipping_country text,
	shipping_country_base_rate numeric(14, 3),
	CONSTRAINT shipping_country_rates_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE public.shipping_transfer_id_sequence start 1;
drop table if exists public.shipping_transfer;
create table public.shipping_transfer
(
	id int2,
	transfer_type text,
	transfer_model text,
	shipping_transfer_rate numeric(14, 3),
	CONSTRAINT shipping_transfer_pkey PRIMARY KEY (id)
);

drop table if exists public.shipping_info;
create table public.shipping_info
(
	shipping_id int8,
	vendor_id int8,
	payment_amount numeric(14, 3),
	shipping_plan_datetime timestamp,
	shipping_transfer_id int2,
	shipping_agreement_id int4,
	shipping_country_rate_id int2,
	CONSTRAINT shipping_info_pkey PRIMARY KEY (shipping_id)
);

drop table if exists public.shipping_status;
create table public.shipping_status
(
	shipping_id int8,
	status text,
	state text,
	shipping_start_fact_datetime timestamp,
	shipping_start_end_datetime timestamp,
	CONSTRAINT shipping_status_pkey PRIMARY KEY (shipping_id)
);

drop table if exists public.shipping_datamart;
create table public.shipping_datamart
(
shipping_id int8,
vendor_id int8,
transfer_type text,
full_day_at_shipping int2,
is_delay int2,
is_shipping_finish int2,
delay_day_at_shipping int2,
vat numeric(14, 3),
profit numeric(14, 3),
CONSTRAINT shipping_datamart_pkey PRIMARY KEY (shipping_id)
);